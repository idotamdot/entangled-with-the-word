# Entangled with the Word ✨🧬

This is a mystical, AI-powered Streamlit app that reinterprets the parables of Jesus through the lens of quantum theory.

- 🚀 Built with Python + Streamlit + OpenAI
- ☁️ Hosted on Microsoft Azure
- 📖 Explore sacred teachings with symbolic elegance

**Created by Jessica McGlothern** – portfolio ready and fully infused with wonder.
